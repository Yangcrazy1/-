# Pocket City V0.7 — development instructions

- The user wants a genuinely playable mobile spherical-city sandbox. Continue implementation when new references arrive; do not stop at plans or ask for routine reversible choices.
- Edit `src-v7/characters.js`, `world.js`, `interface.js`, `interface.css`; use `scripts-v7/build.py` to build. The compatibility core is in `src-v7/runtime-v6-checkpoint.js`.
- Keep the downloadable self-contained HTML below 10,000,000 bytes. Never inflate files to imply quality. Never introduce runtime CDN, remote texture, audio, or font dependencies.
- Keep CJ, Tommy and Michael visually distinguishable. All locomotion states must use the same weighted body mesh. Preserve authored anatomy; do not replace people with poles, capsules or stick figures.
- Retain three connected districts, pedestrians, traffic, police, tasks, driving, aircraft, weapons, wheels, radio and saves. Never silently drop working features during visual upgrades.
- Skin weights must sum to 1 (quantized weights sum to 255). Test deformation at planet-space positions, not only at the local origin.
- Complete world is a sphere; travel across longitude seams and poles must remain continuous. Preserve swept collisions, camera obstruction tests, safe boarding / exiting and non-overlapping building footprints.
- All three fast-travel destinations need visible nearby pedestrians and traffic immediately. Population recycling must preserve passengers, active vehicles, police, targeted actors and wrecks; avoid visible pop-in during normal traversal.
- New sessions begin at 08:00. The day is 300 active seconds. Menus, wheels, overview and background pause the solar clock. Do not advance it from clamped physics time alone.
- Run `python3 scripts-v7/build.py`, `node --check game-v7.js`, `npm test` after relevant code changes. Inspect every failed check. Verify actual mobile layouts through the environment's supported browser preview.
- Do not claim phone FPS, WebGL shader correctness, platform review or store readiness based only on Node tests or a cloud software renderer. Record actual testing limits.
- Preserve `ASSET_MANIFEST.md`, original CC0 credit and the Three.js MIT license. Do not package unlicensed GTA extracted assets or commercial songs; retain local music import and original synthesized stations.
- Do not publish, create an external repository or bind a platform identity without a specified destination. Source packaging and local fixes are already authorized.

## V0.8 continuation

- Read README_V08.md and OPEN_SOURCE.md first. V0.8 uses the existing `scripts-v7/build.py` entry point plus new `src-v8/` modules. Do not edit generated bundles.
- `npm test` now runs `verify-v8.cjs`, retaining all 51 V0.7 checks and adding 10 behavioral checks. Run the browser smoke after changes affecting loading, touch scrolling, renderer or UI.
- Retain taxi, Ferrari-style cars, tracked tank, helicopter and fighter. Native touch scrolling in menus must not be disabled by an ancestor's touch-action.
- Keep file-protocol policy limitations and software GPU measurements separate from actual phone validation. Do not describe the H5 package as approved by Xiaohongshu.
- Use existing isolated checkouts; do not create Git worktrees unless the user requests one.

## V0.9 continuation

- User explicitly prioritizes a downloadable mobile H5 playtest and debugging. Build a Xiaohongshu upload package only when subsequently requested.
- Read README_V09.md. Edit `src-v9/` for coast/landmarks/art/map. The build entry point remains `scripts-v7/build.py`; npm test runs 70 checks through `verify-v9.cjs`.
- Preserve normalized weights when cutting clothing seams. Attach new accessories with skeleton bind inverses, not an animated head/hand world matrix.
- Keep coastal blocking, walkable bridges/pier, clear landmark arrival points, and solid casino/sphinx collision. Browser checks: `scripts-v9/browser-smoke.py`.

## V0.10 fresh bay continuation

- User reference project/session: `01a16708-2512-71fc-94bc-1e85de06a0a9`. Read PROJECT_STATUS.md, README_V10.md, ACCEPTANCE_V10.md and current git status before editing. Current workspace is authoritative; never overwrite it with old ZIPs.
- User selected medium Android, 30 FPS target, and explicitly requires verified HTTPS mobile downloads like V0.9. Keep offline HTML below 10,000,000 bytes. Actual phone performance remains unverified without devices.
- Edit src-v10/ plus necessary compatibility hooks. Config is src-v10/config.json; it is embedded by scripts-v7/build.py. Maintain shared spherical wave/seabed/shore/bridge/walk/vehicle heights and local-frame normals; never project bay decks onto the antipode.
- Signals, pedestrian lights and traffic use one active clock. Retain all-red clearance and in-progress crossing protection. Cars must brake before the stop line and start smoothly; waterfront decks remain pedestrian-only.
- Preserve the same weighted body and skeleton through all protagonist states. Keep normalized weights, bind-space accessories, grounded feet, warm role-specific clothing, and resource disposal when changing actors/previews.
- npm test runs verify-v10.cjs with 81 cases. Legacy assertions remain; the radial error now compares analytic terrain, and melee waits for its preparation time before checking the same damage. Do not weaken those checks.
- UI/render changes require scripts-v10/browser-smoke.py and scripts-v10/acceptance.py; the latter injects QA hooks not present in delivered HTML. Confirm report hashes match the final HTML. Run scripts-v10/endurance.py for final 600-second cloud evidence, and describe SwiftShader limits.
- Update PROJECT_STATUS.md at substantive stages in Chinese progress updates. Keep pre/post camera evidence and explicit acceptance gaps. Package single English-named HTML, runnable ZIP, source, config, screenshots/checklist; verify ZIP CRC and actual HTTPS bytes before claiming delivery.
